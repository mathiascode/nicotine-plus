# List of translators for Nicotine & Nicotine+:

##### English
 * mathiascode (2020)
 * Michael Labouebe (2016) < gfarmerfr (at) free.fr >
 * hyriand
 * daelstorm

##### Dutch
 * nince78 (2007)
 * hyriand

##### German
 * Meokater (2007)
 * (.\_.) (2007)
 * lippel (2004)
 * hyriand (2003)

##### Spanish
 * Silvio Orta (2007)
 * Dreslo

##### French
 * Michael Labouebe (2016-2017) < gfarmerfr (at) free.fr >
 * ManWell (2007)
 * zniavre (2007)
 * flashfr
 * systr

##### Italian
 * Nicola (2007) < info (at) nicoladimaria.info >
 * dbazza

##### Polish
 * Amun-Ra (2007)
 * thine (2007)
 * owczi

##### Swedish
 * alimony < markus (at) samsonrourke.com >

##### Hungarian
 * djbaloo < dj_baloo (at) freemail.hu >

##### Slovak
 * Josef Riha (2006) < jose1711 (at) gmail.com >

##### Portuguese Brazilian
 * Suicide|Solution (2006) < felipe (at) bunghole.com.br >

##### Lithuanian
 * Žygimantas (2006) < uid0 (at) akl.lt >

##### Finnish
 * Kalevi < mr_auer (at) welho.net >

##### Euskara
 * The Librezale.org Team < librezale (at) librezale.org >
