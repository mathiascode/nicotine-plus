# Icon Credits

Created by gfarmerfr (released under Public Domain)

These icons are derived from the Tango Desktop Project Dialog-information.svg icon
(https://commons.wikimedia.org/wiki/File:Dialog-information.svg) which is licensed under Public Domain.

hilite.png  
hilite3.png

---

Created by gfarmerfr (released under LGPLv3+)
Modified by mathiascode

These icons are a combined work between the n.png icons and the gnome-icon-theme
which is licensed under LGPLv3+.

trayicon_away.png  
trayicon_connect.png  
trayicon_disconnect.png  
trayicon_msg.png

---

Created by daelstorm (released under GPLv2+ and upgraded to GPLv3+)
away.png  
empty.png  
offline.png  
online.png

---

Created by Quinox (released under GPLv2+ and upgraded to GPLv3+)
Modified by mathiascode

org.nicotine_plus.Nicotine.svg

---

Country flags under the flags folder are provided by https://github.com/lipis/flag-icon-css

The MIT License (MIT)

Copyright (c) 2013 Panayiotis Lipiridis

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
of the Software, and to permit persons to whom the Software is furnished to do
so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
